package abs;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test t = new Imps();
		t.add(11, 2);
		t.show();
	}

}
