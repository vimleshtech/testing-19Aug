package abs;

public abstract class Test {

	// non-abstract
	public void show() {
		System.out.println("show");
	}
	
	//abstract method s
	public abstract void add(int a, int t) ;
	
	
}
