package arrayexample;

import java.io.FileReader;
import java.net.SocketTimeoutException;

import day05.FileReadAndWrite;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try {
			
		
		FileReader fr = new FileReader("c://abcld//a.txt");
		
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("err....");
		}
		
		int n,d,o;
		n =11;
		d =-33;
		
		try {
			
			if(d<0) {
				Exception er = new Exception("divisor cannot be less than 0");
				throw er;//go to catch block 
			}
			o = n/d;
		
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		
		
	}

}
