package arrayexample;

public class Caller  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test t = new Test();
		t.a();
	
		Test t1 = new Test("us");
		t1.data  =100;
		
		
		
		t1.show();
		
		Test tt = new Test(t1);
		tt.show();
	}
	

}
