package arrayexample;

import java.util.Scanner;

public class Example {

	public static void main(String[] args) {
		
		int n[] = {11,22,243,5556,3};
		
		//print first element
		System.out.println(n[0]);
		
		//print length
		System.out.println(n.length);
		
		//print all date/iterate all data
		for(int i=0; i<n.length;i++) {
			System.out.println(n[i]);
		}
	
		//or - using advance loop
		for(int x: n) {
			System.out.println(x);
		}
		//print sum of all numbers
		int sum=0;
		for(int x: n) {
			sum=sum+x;
		}
		System.out.println("total "+sum);

		//print in reverser 
		for(int i=n.length-1; i>=0;i--) {
			System.out.println(n[i]);
		}
		
		
		//dynamic array
		int size;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter size of array ");
		size = sc.nextInt();
		
		String s[] = new String[size];
		
		for(int i=0; i<size;i++) {
			
			System.out.println("enter data  ");
			s[i]= sc.next();
				
		}
		//print all data 
		for(String t:s) {
			System.out.println(t);
		}
		
	}

}
