package example;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Testcase1 {

	
	static WebDriver driver;
	
	@Test
	public void testA() {
		System.out.println("in test A"); //login
		driver.findElement(By.id("ff")).click();
		
	}

	//@Ignore
	@Test
	public void testC() {
		System.out.println("in test C"); //logout 
	}
	
	@Test
	public void testB() {
		System.out.println("in test B"); //search
	}
	
	@Before
	public void before() {
		System.out.println("before @Test");
	}

	@After
	public void tearDown() {
		System.out.println("after @Test");
	}
	
	@BeforeClass
	public static void beforeClass() {
		
		System.out.println("before class");
		driver = new ChromeDriver();
		driver.get("sbf.com");
	}
	@AfterClass
	public static void afterClass() {
		
		System.out.println("after class");
		
		driver.quit();//close 
	}
	
	
}
