package day072;

public class CurrentAccount extends BankAccount {

	String gstno;
	String regnu;
	
	void newAccount() {
	
		super.newAccount();
		System.out.println("enter address");
		gstno= sc.next();
		System.out.println("enter id");
		regnu= sc.next();			
	}
	
	void dispAccount() {
		
		super.dispAccount();		
		System.out.println("gstn "+gstno);		
		System.out.println("reg no "+regnu);
			
	}

	
}
