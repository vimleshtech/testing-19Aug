package day072;

public interface Ib {

	void tax(int a, int b);
	
}
