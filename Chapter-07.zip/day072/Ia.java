package day072;

public interface Ia {

	void add(int a, int b);
	void div(int a, int b);
	void mul(int a, int b);
	int sub(int a, int b);
	
}
