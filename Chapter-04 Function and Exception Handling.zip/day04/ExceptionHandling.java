package day04;

import java.util.Scanner;

public class ExceptionHandling {

	public static void main(String[] args) {
	
		int n,d,o;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data ");
		n = sc.nextInt();
		
		System.out.println("enter data ");
		d = sc.nextInt();
		
		//
		try {
			if(d<0) {
				ArithmeticException ex = new ArithmeticException("divisor canot less than 0");
				throw ex;
			}
			o = n/d;
			System.out.println("out is "+o);
		}
		catch (ArithmeticException e) {
			
			System.out.println(e.toString());
			
		}
		catch (ArrayIndexOutOfBoundsException e) {
			
			System.out.println(e.toString());
		}
		catch (Exception e) {
			System.out.println("this is some logical error, try with different input");
		}
		finally {//common code which shoule execute always either exception is occur or not
			System.out.println("end of code");
		}
		
		//add 
		o = n+d;
		System.out.println("sum of two numbers:"+o);
		
		
	}

}
