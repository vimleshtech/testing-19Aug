package day02;

import javax.sound.midi.Soundbank;

public class Pattern {

	public static void main(String[] args) {

		//
		int n=2;
		
		for(int i=1; i<10;i++) {
					
			System.out.print(n+",");
			n *=2;
		}

		System.out.println();
		//
		for(int i=1; i<50;i=i+3) {
			
			if(i%2 ==0)//if number is even 
				System.out.println(i*-1);
			else
				System.out.println(i);
			
		}
		
		
		///
		/*
		 * i=2
		 * j =2  2 
		 * --
		 * i = 4 
		 * j = 2  4
		 * -- 
		 * i = 6
		 * j = 2 4 6 
		 */
		for(int i=2; i<10; i=i+2) {
			
			System.out.print("(");
			for(int j=2; j<=i;j=j+2) {
				
				if(j<i)
					System.out.print(j+"+");
				else
					System.out.print(j);
			}
			System.out.print(")+");
			
		}
	}

}
