package day02;

import java.util.Scanner;

public class QB32 {

	public static void main(String[] args) {

		
		Scanner s = new Scanner(System.in);
		int limit;
		System.out.println("enter size :");
		limit = s.nextInt();
		
		int sum=0;
		double avg;
		
		int i=1;
		while(i<=limit) {
			
			sum+=i;
			i++;
		}
		
		System.out.println("sum of all numbers "+sum);
		avg = sum/(i-1);
		System.out.println("average value is "+avg);
		

	}

}
