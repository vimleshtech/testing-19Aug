package day02;

public class NestedLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * i =1 c = 1 2 3 
		 * i =2 c = 1 2 3
		 * i =3 c = 1 2 3
		 * 1
		 * 1
		 * 1
		 * 2
		 * 2
		 * 2
		 * 3
		 * 3
		 * 3 
		 */
		
		for(int i=1; i<4;i++) {
		
			for(int c=1; c<4; c++) {
				System.out.println(i);
			}
			
		}
		
		/*
		 * 1
		 * 2
		 * 3
		 * 1
		 * 2
		 * 3
		 * 1
		 * 2
		 * 3
		 */
		for(int i=1; i<4;i++) {
			
			for(int c=1; c<4; c++) {
				System.out.println(c);
			}
			
		}
		
		/*123123123
		 * 123
		 * 123
		 * 123
		 */
		for(int i=1; i<4;i++) {
			
			for(int c=1; c<4; c++) {
				System.out.print(c+"\t");
			}
			System.out.println();//new line 
			
		}

	}

}
