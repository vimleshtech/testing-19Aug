package day02;

import java.util.Scanner;

public class QB8 {

	public static void main(String[] args) {

		Scanner s =new Scanner(System.in);
		int sal;
		float hra,da;
			
		System.out.println("enter sal ");
		sal = s.nextInt();
		
		if(sal>=5000 && sal<=10000) {
			hra = sal*.10f;
			da = sal*.05f;
			
		}
		else if(sal>10000 && sal<=15000) {
			
			hra = sal*.15f;
			da = sal*.08f;
			
		}else {
			
			hra  = 0;
			da =0;
		}
		
		System.out.println("hra is "+hra);
		System.out.println("da is "+da);
		
		

	}

}
