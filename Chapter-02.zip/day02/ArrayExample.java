package day02;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[] = {11,222,4445,222,4};
		
		//print /access 2nd value
		System.out.println(a[1]);
				
		//access all value
		//x = a; //assign value from right to left
		for(int x: a) //advance loop  , assign value from right to left one by one
		{
			System.out.println(x);
		}
				
		//or
		int n[] = new int [3];
		n[0]=133;
		n[1]=144;
		n[2]=155;
		
		System.out.println(n[1]);
		
		//input from user
		Scanner s =new Scanner(System.in);
		int size;
		System.out.println("enter size of array ");
		size = s.nextInt();
		
		String name[] = new String[size];
		
		for(int i=0; i<size;i++) {
			
			System.out.println("enter data for array ");
			name[i] = s.next();
		}
		
		//print 
		for(String na: name) {
			System.out.println(na);
		}
		
	}

}
 