package day06;

public class Calc {

	
	int x;
	static int y;
	
	int a;
	int b;
	int c;
	
	//read only 
	final int tax_slab=300000;
	
	 void add(int a, int b) {
		
		this.a = a;
		this.b = b;
		//a++;
		this.c =this.a+this.b;
		
		//we cannot change value
		//tax_slab =45545;
		
	}
	
	void show() {
		
		System.out.println("sum of "+a+" and "+b+" is "+c);
	}
	
	
}
