package day06;

public class Caller {

	public static void main(String[] args) {

		
		Calc c = new Calc();
		Calc c1 = new Calc();
		
		c.add(11, 33);
		c.show();
		
		//Calc.add(111, 33);
		System.out.println("ff");
		Calc.y =44;
		//Calc.x =44;
		c.x=11;   //x is not static 
		c1.x=110;
		c.y=11;   //y is static 
		c1.y=110;
		
		
		System.out.println(c.x);   //
		System.out.println(c1.x); // 
		System.out.println(c.y); //110
		System.out.println(c1.y); //110
		
		//
		
		
		J4 o = new J4();
		o.Input();
		o.Calcgrade();
		o.Dispdata();
		//o.Average =554.53f;
		
		
		
	}

}
