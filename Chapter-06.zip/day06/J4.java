package day06;

import java.util.Scanner;

public class J4 {

	private int rollno	;//	-roll number
	//char name[] = null; //	- name
	private String name;
	private float marks[] = new float[5]; //	- marks in 5 subjects
	float Total=0;		//-total marks
	private float Average;		//-average marks
	String Grade; //

	
	public void Input( )		//- to input the data
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name ");
		name = sc.next();
		
		System.out.println("enter roll nu");
		rollno =  sc.nextInt();
		
		System.out.println("enter mark in 5 subjects ");
		
		for(int i=0;i<5; i++)
			marks[i] = sc.nextFloat();
		
	}
	void Calcgrade( )//		- to calculate total, average and grade
	{
		
		for(float f : marks)
			Total+=f;
		
		Average = Total/5;
		if(Average>80) {
			Grade="A";
			
		}
		else if(Average>60) {
			Grade="B";
			
		}
		else if(Average>40) {
			Grade="C";
			
		}
		else {
			Grade="D";
			
		}
		
	}
	void Dispdata( )
	{
		System.out.println("name is "+name);
		System.out.println("rno is "+rollno);
		System.out.println("total score is "+Total);
		System.out.println("Average score is "+Average);
		System.out.println("Grade is "+Grade);
		
		
		
		
	}
	
	
}
