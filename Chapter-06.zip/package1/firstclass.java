package package1;

import day06.J4;

public class firstclass {


public static void main(String[] arg) 
{

	J4 j = new J4();
	j.Input();
	
	
	//declare variables
	int a,b,c;
	
	//assign data on variable 
	a =44;
	b =55;
	
	//expression 
	c = a+b;
	
	System.out.println("sum of two numbers "+c);
	
	
	
}		
	
}