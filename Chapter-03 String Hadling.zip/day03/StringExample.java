package day03;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
		
		String name,ns;
		Scanner s = new Scanner(System.in);
		
		System.out.println("enter name ");
		name = s.nextLine();
		
		//
		ns = name.toUpperCase();
		System.out.println(ns);
		
		//
		ns = name.toLowerCase();
		System.out.println(ns);

		//
		//
		ns = name.replace("a", "xy");
		System.out.println(ns);


		//
		int l = name.length();
		System.out.println(l);
		
		//
		ns = name.substring(2,6);// 2 3 4 5 
		System.out.println(ns);
		
		//
		int i = name.indexOf("is"); //return -1 if not match
		System.out.println(i);
		
		//
		ns= name.concat("sinha");
		System.out.println(ns);
		
		//
		if(name.equals("nitin")) {
			System.out.println("string is match");
		}else {
			System.out.println("string is not match");
		}
		//
		
		if(name.equalsIgnoreCase("nitin")) {
			System.out.println("string is match");
		}else {
			System.out.println("string is not match");
		}
		
		//
		if(name.contains("nitin")) {
			System.out.println("nitin contains in string");
		}else {
			System.out.println("string is not match");
		}
		
		//
		if(name.startsWith("nitin")) {
			System.out.println("string is match");
		}else {
			System.out.println("string is not match");
		}
		
		//
		if(name.endsWith("sinha")) {
			System.out.println("string is match");
		}else {
			System.out.println("string is not match");
		}
		
		//
		String n[] = name.split(" ");
		System.out.println(n[0]); //first name
		System.out.println(n[1]); //last name
		
		//get array size 
		System.out.println(n.length);
		
	}
	

}
