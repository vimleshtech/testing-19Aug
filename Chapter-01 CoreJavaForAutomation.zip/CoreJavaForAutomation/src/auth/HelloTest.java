package auth;

public class HelloTest 
{
	//Comment : inactive code 
	//wap to show addition of two numbers
	
	public static void main(String[] arg) 
	{
	
		//declare variables
		int a,b,c;
		
		//assign data on variable 
		a =44;
		b =55;
		
		//expression 
		c = a+b;
		
		System.out.println("sum of two numbers "+c);
		
		
		
				
		
	}
	
	
}