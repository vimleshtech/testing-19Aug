package auth;

//import java.util.*; //import all library or class from util package

import java.util.Scanner;  //import one class
import java.util.ArrayList;

public class Exampl2 {

	public static void main(String[] args) {

		
		System.out.println("hi");
		System.out.println("Raman");

		
		System.out.print("hi");
		System.out.println("Raman");
		
		System.out.println(); //can be work without argument 
		System.out.print(""); //will not work without argument 
		

		
		//create an object of class
		Scanner s = new Scanner(System.in); //input
		
		int a,b,c;
		
		System.out.println("enter data ");
		a = s.nextInt(); //nextInt() is function to read numeric value
		
		
		System.out.println("enter data ");
		b = s.nextInt(); //nextInt() is function to read numeric value
		
		
		String name;
		System.out.println("enter name ");
		name = s.next(); //read string 
		
		c = a+b;
		
		System.out.println("sum = "+c);
		
		System.out.println("you have entered "+name);
	}

}
