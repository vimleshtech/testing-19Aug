package day05;

import java.util.Scanner;

public class ArrayQ3 {

	public static void main(String[] args) {

		//declare array 
		int a[]= new int[5];
		int b[]= new int[5];
		
		Scanner sc = new Scanner(System.in);
		
		//read char
		//System.out.println("enter char");
		//char x[] = sc.next().toCharArray(); //read multiple/char array		
		//char x = sc.next().charAt(0); //read one char
		
		//input from array-1
		for(int i=0; i<5;i++) {
		
			System.out.println("enter data for array 1");
			a[i] =sc.nextInt();//assign value
		}
		//input from array-2
		for(int i=0; i<5;i++) {
		
			System.out.println("enter data for array 2");
			b[i] =sc.nextInt();
		}		
		//substruct 
		for(int i=0;i<5;i++) {
			System.out.println(a[i]-b[i]);
		}
	}

}
