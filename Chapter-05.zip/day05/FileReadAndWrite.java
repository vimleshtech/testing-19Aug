package day05;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadAndWrite {

	public static void main(String[] args) throws IOException {

		//writeFile();
		readFile();

	}
	
	public static void readFile() throws IOException {
		
	
		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\Tax\\out.txt"); 
		BufferedReader br = new BufferedReader(fr);
	
		String data=br.readLine();
		//get no of lines
		int rc=0;
		//get word count
		int wc=0;
		
		while(data!=null) {
		
			rc++;
			//word count
			String w[] = data.split(" ");
			wc+= w.length;
			
			System.out.println(data);
			
			
			data = br.readLine();
		}
		
		System.out.println("row count "+rc);
		System.out.println("word count "+wc);
		br.close();
		fr.close();
		
	}
	public static void writeFile() throws IOException {
		
		// \  : is not allowed
		// \\ or / : is allowed
		// code should be in try block or add throws 
		//create new file if not exist and overwrite if exist 
		
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\Tax\\out.txt",true); //true - append mode
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write("gjkgfhfg");
		bw.newLine();
		bw.write("hi, this is test file1123");
		bw.newLine();
		bw.write("hi, this is test file444");
		bw.newLine();
		
		//to save and close file
		bw.close();
		fw.close();
	}

}
